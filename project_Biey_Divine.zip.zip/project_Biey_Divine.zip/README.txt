Mijn project staat online op webspace Infinityfreecom

Ik heb  Filezilla gebruikt voor de webserver request

Hier is de link naar project: 

http://divinebiey.lovestoblog.com